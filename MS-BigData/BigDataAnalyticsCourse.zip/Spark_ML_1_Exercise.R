################# Exercise 1 (Page 23)

sql("use class")
taxi_df_raw <- sql("select * from nyc_taxi_Jan where day(pickup_datetime) = 1 and day(dropoff_datetime) = 1 and hour(pickup_datetime) = 19 and hour(dropoff_datetime) = 19")
taxi_df <- dropna(taxi_df_raw)
taxi_df$fare_label = ifelse(taxi_df$fare_amount > 15, 1, 0)

df_list <- randomSplit(taxi_df, c(7,3), 2)
taxi_training_df <- df_list[[1]]
taxi_testing_df <- df_list[[2]]

model <- spark.randomForest(taxi_training_df,  fare_label ~ pickup_latitude+pickup_longitude+dropoff_longitude+dropoff_latitude+rate_code+trip_distance , "classification", numTrees = 20, maxDepth = 10, maxMemoryInMB = 2048)

output <- predict(model, taxi_testing_df)

correct <- nrow(where(output, fare_label == prediction))
total <- nrow(output)
accuracy = correct/total

TP <- nrow(where(output, output$fare_label == 1 & output$prediction == 1))
FP <- nrow(where(output, output$fare_label == 0 & output$prediction == 1))
Precision = TP/(TP+FP)

FN <- nrow(where(output, output$fare_label == 1 & output$prediction == 0))
Recall = TP/(TP+FN)



############### Exercise 2 (Page 34) based on previous exercise results

model_reg <- spark.glm(taxi_training_df,  fare_amount ~ pickup_latitude+pickup_longitude+dropoff_longitude+dropoff_latitude+rate_code+trip_distance , family = "gaussian")

output <- predict(model_reg, taxi_testing_df)

showDF(select(output, avg((output$fare_amount-output$prediction)^2)))  ## MSE
showDF(select(output, sqrt(avg((output$fare_amount-output$prediction)^2)))) ##RMSE
showDF(select(output, avg(abs(output$fare_amount-output$prediction)))) ## MAE
showDF(select(output, avg(abs(output$fare_amount-output$prediction)/abs(output$fare_amount))))  ## MAPE



