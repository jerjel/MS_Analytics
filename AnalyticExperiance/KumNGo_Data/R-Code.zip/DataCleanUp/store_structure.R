#KUM & GO STORE STRUCTURE EVALUATION PROJECT -- U IOWA MSBA

#STORE STRUCTURE DETERMINED HOURS TO SCHEDULED HOURS (AS SET BY GM) -- COMBINED CLEANING SCRIPT

#####

#PACKAGES USED

library(tidyverse)
library(lubridate)
library(dplyr)
library(tidyr)
library(readxl)


#####

#ASSUMPTIONS MADE

#PayCode = "Hourly Pay"
#WorkingIndicator = 1
#ScheduleVersion = 2                  

#after running script and examining output, AssociateID #126914 and #132625 have mostly had overnight shifts -- wrongly identified in survey (and therefore removed for survey file)



##### CLEAN THE SCHEDULED BY GM TABLE: "scheduled"

scheduled <- read.csv("2019-11-15_factScheduledHours_District7.csv", stringsAsFactors = FALSE)

#StartTimeDate is not in POSIXct format -- using alt key to correct:

scheduled_altkey <- scheduled$ScheduledHoursAlternateKey
scheduled_altkey <- unlist(strsplit(scheduled_altkey, "|", fixed = TRUE))

date <- scheduled_altkey[seq(3,length(scheduled_altkey),by = 8)]
time <- scheduled_altkey[seq(4,length(scheduled_altkey),by = 8)]

#Derive Year, Month, Day, Hour, and Minute from worked_altkey list

start_hour <- c()
start_minute <- c()

j <- 1

for(i in 1:nrow(scheduled)){
  
  if(nchar(time[i]) == 5){
    
    start_hour[j] <- substr(time[i],1,1)
    start_minute[j] <- substr(time[i],2,3)
    
    j <- j + 1
    
  } else {
    
    start_hour[j] <- substr(time[i],1,2)
    start_minute[j] <- substr(time[i],3,4)
    
    j <- j + 1
  }}


year <- as.integer(substr(date,1,4))
month <- as.integer(substr(date,5,6))
day <- as.integer(substr(date,7,8))

scheduled$StartTime <- paste(start_hour, ":", start_minute, ":00", sep = "")
scheduled$StartDateTime <- paste(year, "/", month, "/", day, " ", scheduled$StartTime,sep = "")

scheduled$StartDateTime <- as.POSIXct(scheduled$StartDateTime,format="%Y/%m/%d %H:%M")

##same process for EndTimeDate

date_end <- scheduled_altkey[seq(5,length(scheduled_altkey),by = 8)]
time_end <- scheduled_altkey[seq(6,length(scheduled_altkey),by = 8)]

#Derive Year, Month, Day, Hour, and Minute from worked_altkey list

start_hour_end <- c()
start_minute_end <- c()

k <- 1

for(m in 1:nrow(scheduled)){
  
  if(nchar(time_end[m]) == 5){
    
    start_hour_end[k] <- substr(time_end[m],1,1)
    start_minute_end[k] <- substr(time_end[m],2,3)
    
    k <- k + 1
    
  } else {
    
    start_hour_end[k] <- substr(time_end[m],1,2)
    start_minute_end[k] <- substr(time_end[m],3,4)
    
    k <- k + 1
  }}


year_end <- as.integer(substr(date_end,1,4))
month_end <- as.integer(substr(date_end,5,6))
day_end <- as.integer(substr(date_end,7,8))

scheduled$EndTime <- paste(start_hour_end, ":", start_minute_end, ":00", sep = "")
scheduled$EndDateTime <- paste(year_end, "/", month_end, "/", day_end, " ", scheduled$EndTime,sep = "")

scheduled$EndDateTime <- as.POSIXct(scheduled$EndDateTime,format="%Y/%m/%d %H:%M")


#####
#sometimes the read.csv will read StartTimeDate in the desired date format; but then, columns are unnamed (use this code in that case)

# col_names <- c("ScheduledHoursKey", "ScheduledHoursAlternateKey",	"LogKey",	"StartDateKey", 	"EndDateKey",	"BookDateKey",	"SiteKey",	"SiteCurrentKey", "SWHAlternateKey",
#                "CostCenterKey",	"StartTimeKey",	"EndTimeKey",	"AssociateKey",	"KronosSite",	"SiteNumber",	"AssociateID",	"CostCenter",
#                "ScheduleVersion",	"WeeksOut",	"JobType",	"PayCode",	"StartDate",	"StartTime",	"StartDateTime",	"EndDate",	"EndTime",
#                "EndDateTime",	"BookDate",	"ScheduleHours",	"ExtractDate",	"SourceID",	"SourceConfigID",	"OriginalSourceConfigID",	"CreateDate",
#                "WorkingIndicator",	"InStoreIndicator",	"BaseIndicator",	"DistrictNumber",	"Division", "JobProfile")
# 
# for(a in 1:ncol(scheduled)){
#   names(scheduled)[a] <- col_names[a]
# }

#earlier versions of code ran on dataframe that did not have ScheduledHoursAlternateKey column...thus, removing now
scheduled$ScheduledHoursAlternateKey <- NULL

scheduled$Division <- factor(scheduled$Division)
scheduled$DistrictNumber <- factor(scheduled$DistrictNumber)
scheduled$JobType <- factor(scheduled$JobType)
scheduled$BaseIndicator <- factor(scheduled$BaseIndicator)
scheduled$PayCode <- factor(scheduled$PayCode)
scheduled$WorkingIndicator <- factor(scheduled$WorkingIndicator)
scheduled$DistrictNumber <- factor(scheduled$DistrictNumber)
#scheduled$AssociateID <- factor(scheduled$AssociateID)
scheduled$CostCenter <- factor(scheduled$CostCenter)
#scheduled$SiteNumber <- factor(scheduled$SiteNumber)
scheduled$InStoreIndicator <- factor(scheduled$InStoreIndicator)
scheduled$WeeksOut <- factor(scheduled$WeeksOut)
scheduled$ScheduleVersion <- factor(scheduled$ScheduleVersion)
scheduled$day_of_week <- factor(weekdays.POSIXt(scheduled$StartDateTime))
scheduled$month <- factor(months.POSIXt(scheduled$StartDateTime))
scheduled$start_hour <- hour(scheduled$StartDateTime)
scheduled$JobProfile <- factor(scheduled$JobProfile)

#####

scheduled <- filter(scheduled, WorkingIndicator == 1, PayCode == "Hourly Pay")
scheduled <- scheduled[c(1, 34:38,14,15,17,18,19,20,39, 23, 26, 28)]

scheduled$SortableDate <- NA

for(i in 1:nrow(scheduled)){
  a <- month(scheduled$StartDateTime[i])
  if(a < 10){
    a <- paste("0", as.character(a), sep = "")
  } else {
    a <- as.character(a)
  }
  b <- day(scheduled$StartDateTime[i])
  if(b < 10){
    b <- paste("0", as.character(b), sep = "")
  } else {
    b <- as.character(b)
  }
  scheduled$SortableDate[i] <- paste(as.character(year(scheduled$StartDateTime[i])), a, b, sep ="")
}

#Create Midnight Start Time Indicator Variable

scheduled$start_hour <- hour(scheduled$StartDateTime)
scheduled$midnight_indicator <- 0 

for(l in 1:nrow(scheduled)){
  if(scheduled$start_hour[l] == 0){
    scheduled$midnight_indicator[l] <- 1
  }
}

scheduled$start_hour <- NULL

scheduled$day_of_week <- weekdays(scheduled$StartDateTime)

scheduled <- scheduled[, c(17,1:6,9,10,7,8,12,11, 13,19, 14:16, 18)]
scheduled$week_in_year <- isoweek(scheduled$StartDateTime)
scheduled$iso_year <- isoyear(scheduled$StartDateTime)

scheduled <- scheduled[order(scheduled$AssociateID, scheduled$SortableDate, scheduled$StartDateTime), ]




##### CLEAN EDITED SURVEY RESULTS FILE (see line 24) AND MERGE WITH "scheduled" -- ASSIGN SS_JobDescriptionS AND CONTINUE CLEANING

survey <- read.csv("2019-11-11_SurveyResults_edited.csv", stringsAsFactors = FALSE)
names(survey)[1] <- "AssociateID"
names(survey)[3] <- "SS_JobDescription"

#Side note: useful to place the SS_JobDescription column in now before additional merging takes place -- can manually enter GM, Assistant Manager, and Food Manager JobTypes
scheduled <- merge(scheduled, survey, by = c("AssociateID", "SiteNumber"), all.x = TRUE)

for(r in 1:nrow(scheduled)){
  if(scheduled$JobProfile[r] == "Assistant Manager"){
    scheduled$SS_JobDescription[r] <- "Assistant Manager"
  }
  if(scheduled$JobProfile[r] == "General Manager"){
    scheduled$SS_JobDescription[r] <- "General Manager"
  }
  if(scheduled$JobProfile[r] == "Food Manager"){
    scheduled$SS_JobDescription[r] <- "Food Manager"
  }
  if(scheduled$JobProfile[r] == "Store Associate - Food - FT"){
    scheduled$SS_JobDescription[r] <- "Store Associate - Food"
  }
  if(scheduled$JobProfile[r] == "Part Time Store Structure"){
    scheduled$SS_JobDescription[r] <- "Not Applicable - Part Time"
  }
  if(scheduled$JobProfile[r] == "Overnight Lead" & is.na(scheduled$SS_JobDescription[r]) == TRUE){
    scheduled$SS_JobDescription[r] <- "Unknown"
  }
  if(scheduled$JobProfile[r] == "Store Associate - FT" & is.na(scheduled$SS_JobDescription[r]) == TRUE){
    scheduled$SS_JobDescription[r] <- "Unknown"
  }
  
}

scheduled <- scheduled %>% filter(JobType != "Default")

##### IMPORT STORE STRUCTURE FILE CREATED IN EXCEL AND CLEAN: "structure"

#           Has been designed to count both instances of missed shifts:
#                                                         1) GM scheduled employee on a non-Store Structure day
#                                                         2) GM did not properly scheduled employee on a Store Structure designated day tot work

structure <- read_xlsx("Store_Structure_Schedule_v3.xlsx", sheet = 1)

structure[,7:13] <- NULL
names(structure)[1] <- "JobType"

for(zy in nrow(structure)){
  if(is.na(structure$day_of_week[zy]) == FALSE){
    structure$day_of_week[zy] <- as.character(structure$day_of_week[zy])
  }
}

structure$start_time_2 <- structure$start_time
structure$start_time_2 <- as.character(structure$start_time_2)

for(y in 1:nrow(structure)){
  if(is.na(structure$start_time_2[y]) == TRUE){
    next
  }
  if((nchar(structure$start_time_2[y])) == 3 & substr(structure$start_time_2[y],2,3) == "00"){
    structure$start_time_2[y] <- paste(substr(structure$start_time_2[y],1,1), ".0", sep = "")
  } 
  
  if((nchar(structure$start_time_2[y])) == 3 & substr(structure$start_time_2[y],2,3) == "30"){
    structure$start_time_2[y] <- paste(substr(structure$start_time_2[y],1,1), ".5", sep = "")
  } 
  
  if((nchar(structure$start_time_2[y])) == 4 & substr(structure$start_time_2[y],3,4) == "30"){
      structure$start_time_2[y] <- paste(substr(structure$start_time_2[y],1,2), ".5", sep = "")
    } 
  
  if((nchar(structure$start_time_2[y])) == 4 & substr(structure$start_time_2[y],3,4) == "00"){
    structure$start_time_2[y] <- paste(substr(structure$start_time_2[y],1,2), ".0", sep = "")
  } 
}

structure$start_time_2 <- as.numeric(structure$start_time_2)

# Store structure start/end times and shift length in seconds for Gantt Chart in Tableau
structure$SS_start_seconds <- structure$start_time_2 * 60^2
structure$struc_shift_length <- structure$ScheduleHours * 60^2
structure$SS_end_seconds <- structure$SS_start_seconds + structure$struc_shift_length

structure$start_time_2 <- NULL
structure$struc_shift_length <- NULL

for(ab in 1:nrow(structure)){
  
  if(structure$day_of_week[ab] == "1" & is.na(structure$day_of_week[ab]) == FALSE){
    structure$day_of_week[ab]<-"Monday"
  } else
    if(structure$day_of_week[ab] == "2" & is.na(structure$day_of_week[ab]) == FALSE){
      structure$day_of_week[ab]<-"Tuesday"
    } else
      if(structure$day_of_week[ab] == "3" & is.na(structure$day_of_week[ab]) == FALSE){
        structure$day_of_week[ab]<-"Wednesday"
      } else
        if(structure$day_of_week[ab] == "4" & is.na(structure$day_of_week[ab]) == FALSE){
          structure$day_of_week[ab]<-"Thursday"
        } else
          if(structure$day_of_week[ab] == "5" & is.na(structure$day_of_week[ab]) == FALSE){
            structure$day_of_week[ab]<-"Friday"
          } else
            if(structure$day_of_week[ab] == "6" & is.na(structure$day_of_week[ab]) == FALSE){
              structure$day_of_week[ab]<-"Saturday"
            } else
              if(structure$day_of_week[ab] == "7" & is.na(structure$day_of_week[ab]) == FALSE){
                structure$day_of_week[ab]<-"Sunday"
              }
}
  
structure$day_of_week <- as.character(structure$day_of_week)
names(structure)[4] <- "SS_StartTime"
names(structure)[5] <- "SS_ScheduledHours"
structure$SS_ScheduledHours <- as.numeric(structure$SS_ScheduledHours)

structure$SS_EndTime <- NA

for(i in 1:nrow(structure)){
  if(is.na(structure$SS_StartTime[i]) == TRUE){
    next
  }
  
  if(structure$SS_StartTime[i] == 0){
    structure$SS_StartTime[i] <- "0:00:00"
    structure$SS_EndTime[i] <- paste(as.character(structure$SS_ScheduledHours[i]), ":00:00", sep = "")
  }else if(nchar(structure$SS_StartTime[i]) == 4){
    structure$SS_StartTime[i] <- paste((substr(structure$SS_StartTime[i],1,2)), ":", (substr(structure$SS_StartTime[i],3,4)), ":00", sep = "")
    structure$SS_EndTime[i] <- paste(( as.character((as.integer(substr(structure$SS_StartTime[i],1,2))) + structure$SS_ScheduledHours[i]) ), ":", (substr(structure$SS_StartTime[i],4,5)), ":00", sep = "")
  }else{
    structure$SS_StartTime[i] <- paste((substr(structure$SS_StartTime[i],1,1)), ":", (substr(structure$SS_StartTime[i],2,3)), ":00", sep = "")
    structure$SS_EndTime[i] <- paste(( as.character((as.integer(substr(structure$SS_StartTime[i],1,1))) + structure$SS_ScheduledHours[i] )),":", (substr(structure$SS_StartTime[i],3,4)), ":00", sep = "")
  }
}

structure <- structure[ , c(1:4,12, 5:11)]

##### IMPORT A TABLE CREATED IN EXCEL WHICH RELATES SORTABLEDATE TO YEARS, ISO_YEARS, AND MONTHS: "date_table" -- MERGE TO EXISTING "scheduled" AND "structure"

date_table <- read.csv("SortableDates.csv", stringsAsFactors = FALSE)
names(date_table)[1] <- "SortableDate"
date_table <- date_table[,c(1:6)]

#Note: week_in_year does not agree completely with the variable year; rather, it corresponds to iso_year, which has been removed to avoid later confusion

for(tt in 1:nrow(date_table)){
  if(date_table$month[tt] == 1){
    date_table$month[tt] <- "January"
    next
  }
  if(date_table$month[tt] == 2){
    date_table$month[tt] <- "February"
    next
  }
  if(date_table$month[tt] == 3){
    date_table$month[tt] <- "March"
    next
  }
  if(date_table$month[tt] == 4){
    date_table$month[tt] <- "April"
    next
  }
  if(date_table$month[tt] == 5){
    date_table$month[tt] <- "May"
    next
  }
  if(date_table$month[tt] == 6){
    date_table$month[tt] <- "June"
    next
  }
  if(date_table$month[tt] == 7){
    date_table$month[tt] <- "July"
    next
  }
  if(date_table$month[tt] == 8){
    date_table$month[tt] <- "August"
    next
  }
  if(date_table$month[tt] == 9){
    date_table$month[tt] <- "September"
    next
  }
  if(date_table$month[tt] == 10){
    date_table$month[tt] <- "October"
    next
  }
  if(date_table$month[tt] == 11){
    date_table$month[tt] <- "November"
    next
  }
  if(date_table$month[tt] == 12){
    date_table$month[tt] <- "December"
  }
}

date_table$SortableDate <- as.character(date_table$SortableDate)

scheduled <- left_join(scheduled, date_table, by = c("SortableDate", "week_in_year", "day_of_week", "iso_year"))

structure <- left_join(structure, date_table, by = c("iso_year", "week_in_year", "day_of_week"))
structure <- structure %>% filter(is.na(month) == FALSE)
structure <- structure[,c(1:13)]

##### CREATE A COMBINATION OF "structure" AND "scheduled": "combo"

combo <- left_join(scheduled, structure, by = c("iso_year", "week_in_year", "SortableDate", "JobType", "JobProfile", "SS_JobDescription", "midnight_indicator", "day_of_week"))
combo <- combo %>% arrange(AssociateID, SortableDate)
#maintaining sorting order is important to many loops below!

#merging below is related to our goal of including missing shifts; requires creation of "structure_2" to eventually merge back into "combo"
# Notably, "structure_2" will include the variable: AssociateID

structure_2 <- structure %>% filter( (JobProfile != "Store Structure Part Time" & JobProfile != "Overnight Lead" & JobProfile != "Store Associate - FT") & is.na(SS_StartTime) == FALSE)

employees <- scheduled[, c("AssociateID", "week_in_year", "iso_year", "JobType", "JobProfile")]
employees <- distinct(employees)
employees <- employees %>% filter(JobProfile != "Part Time Store Structure", is.na(AssociateID) == FALSE)

structure_2 <- merge(structure_2, employees, by = c("JobType", "JobProfile", "week_in_year", "iso_year"))
structure_2 <- structure_2 %>% arrange(AssociateID, week_in_year)

##### MERGE "structure_2" AND "combo" -- CONTINUE TO CLEAN "combo"

combo <- full_join(structure_2, combo, by = c("AssociateID", "iso_year", "week_in_year", "SortableDate", "JobType", "JobProfile", "SS_JobDescription", "midnight_indicator", "SS_StartTime", "SS_EndTime", "SS_start_seconds", "SS_end_seconds", "SS_ScheduledHours"))
combo <- combo %>% arrange(AssociateID, SortableDate)

combo$day_of_week <- NA

for(nn in 2:(nrow(combo)-1)){
  if(is.na(combo$day_of_week.x[nn]) == FALSE & is.na(combo$day_of_week.y[nn]) == FALSE){
    combo$day_of_week[nn] <- combo$day_of_week.y[nn]
  }
  if(is.na(combo$day_of_week.x[nn]) == TRUE & is.na(combo$day_of_week.y[nn]) == FALSE){
    combo$day_of_week[nn] <- combo$day_of_week.y[nn]
  }
  if(is.na(combo$day_of_week.x[nn]) == FALSE & is.na(combo$day_of_week.y[nn]) == TRUE){
    combo$day_of_week[nn] <- combo$day_of_week.x[nn]
  }
 
  if(substr(combo$SortableDate[nn], 1, 4) == "2018"){
    combo$year[nn] <- 2018
  }
  if(substr(combo$SortableDate[nn], 1, 4) == "2019"){
    combo$year[nn] <- 2019
  }
  
  if(substr(combo$SortableDate[nn], 5, 6) == "01"){
    combo$month[nn] <- "January"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "02"){
    combo$month[nn] <- "February"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "03"){
    combo$month[nn] <- "March"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "04"){
    combo$month[nn] <- "April"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "05"){
    combo$month[nn] <- "May"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "06"){
    combo$month[nn] <- "June"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "07"){
    combo$month[nn] <- "July"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "08"){
    combo$month[nn] <- "August"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "09"){
    combo$month[nn] <- "September"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "10"){
    combo$month[nn] <- "October"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "11"){
    combo$month[nn] <- "November"
  }
  if(substr(combo$SortableDate[nn], 5, 6) == "12"){
    combo$month[nn] <- "December"
  }
  
##the code below attempts to fill in data points that were removed via merging, but are known. Not perfect -- the first 3 lines (after running script completely) of "combo" have NAs for SiteNumber 
  
  if( (is.na(combo$SiteNumber[nn]) == TRUE) & (combo$AssociateID[nn-1] == combo$AssociateID[nn]) ){
    combo$SiteNumber[nn] <- combo$SiteNumber[nn-1]
    combo$DistrictNumber[nn] <- combo$DistrictNumber[nn-1]
    combo$Division[nn] <- combo$Division[nn-1]
  }else if( (is.na(combo$SiteNumber[nn]) == TRUE) & (combo$AssociateID[nn] == combo$AssociateID[nn+1]) ){
    combo$SiteNumber[nn] <- combo$SiteNumber[nn+1]
    combo$DistrictNumber[nn] <- combo$DistrictNumber[nn+1]
    combo$Division[nn] <- combo$Division[nn+1]
  }
  
}

combo$day_of_week.x <- NULL
combo$day_of_week.y <- NULL

combo <- distinct(combo)

## Create POSIXct dates for Store Structure start and end times

combo$SS_StartDateTime <- NA
combo$SS_EndDateTime <- NA

for(j in 1:nrow(combo)){
  if(is.na(combo$SS_StartTime[j]) == TRUE){
    next
  }else{
     combo$SS_StartDateTime[j] <- paste( (as.character(year(combo$StartDateTime[j]))), "-", (as.character(month(combo$StartDateTime[j]))), "-", (as.character(day(combo$StartDateTime[j]))), " ", combo$SS_StartTime[j], sep = "" )

     if((substr(combo$SS_EndTime[j],1,2) == "24")){
      combo$SS_EndDateTime[j] <- paste( (as.character(year(combo$EndDateTime[j]))), "-", (as.character(month(combo$EndDateTime[j]))), "-", (as.character((day(combo$EndDateTime[j])))), " ", "00:00:00", sep = "" )
    }else{
      combo$SS_EndDateTime[j] <- paste( (as.character(year(combo$EndDateTime[j]))), "-", (as.character(month(combo$EndDateTime[j]))), "-", (as.character(day(combo$EndDateTime[j]))), " ", combo$SS_EndTime[j], sep = "" )
    }

  }
}

combo$SS_StartDateTime <- as.POSIXct(combo$SS_StartDateTime, format = "%Y-%m-%d %H:%M:%S")
combo$SS_EndDateTime <- as.POSIXct(combo$SS_EndDateTime, format = "%Y-%m-%d %H:%M:%S")
combo$SS_StartTime <- NULL
combo$SS_EndTime <- NULL

c_order <- c("SortableDate", "ScheduledHoursKey",  "WorkingIndicator", "InStoreIndicator", "BaseIndicator", "DistrictNumber", "Division", "SiteNumber", "ScheduleVersion", "WeeksOut", "PayCode", "AssociateID", "JobType", "JobProfile",  "SS_JobDescription", "year", "month", "week_in_year", "day_of_week",  "StartDateTime", "EndDateTime", "ScheduleHours", "SS_StartDateTime", "SS_EndDateTime", "SS_ScheduledHours", "SS_start_seconds", "SS_end_seconds", "midnight_indicator")
combo <- combo[, c_order]
  

#Calculation Function for difference between two times
hrs_covered_calc <- function(s_start, s_end, w_start, w_end) {
  
  if(w_start >= s_end){
    y <- 0
    return(y)
    break
  }
  
  if(w_end <= s_start){
    y <- 0
    return(y)
    break
  }
  
  if(w_start >= s_start & w_end <= s_end){
    y <- as.numeric(difftime(w_end, w_start, units = "hours"))
    return(y)
    break
  } 
  
  if(w_start <= s_start & w_end <= s_end){
    y <- as.numeric(difftime(w_end, s_start, units = "hours"))
    return(y)
    break
  }
  
  if(w_start >= s_start & w_end >= s_end){
    y <- as.numeric(difftime(s_end, w_start, units = "hours"))
    return(y)
    break
  }
  
  if(w_start <= s_start & w_end >= s_end){
    y <- as.numeric(difftime(s_end, s_start, units = "hours"))
    return(y)
    break
  }
}

##### BEGIN TO CALCULATE SHIFT-BY-SHIFT LEVEL METRICS (Better to use R than Tableau in this case)

combo$SS_HrsCovered <- NA

for(t in 1:nrow(combo)){
  if(is.na(combo$SS_StartDateTime[t]) == TRUE & is.na(combo$SS_EndDateTime[t]) == TRUE){
    next
  }else{
  combo$SS_HrsCovered[t] <- hrs_covered_calc(combo$SS_StartDateTime[t], combo$SS_EndDateTime[t], combo$StartDateTime[t], combo$EndDateTime[t])
  }
}

combo <- combo %>% arrange(AssociateID, SortableDate, StartDateTime)

combo$days_off <- 0

for(x in 2:nrow(combo)){
  if(is.na(combo$AssociateID[x-1]) == TRUE | is.na(combo$AssociateID[x]) == TRUE | is.na(combo$SiteNumber[x-1]) == TRUE  | is.na(combo$SiteNumber[x]) == TRUE |
     is.na(combo$StartDateTime[x-1]) == TRUE | is.na(combo$StartDateTime[x]) == TRUE ){
    next
  }
  
  if(combo$AssociateID[x-1] != combo$AssociateID[x]){
    next
  }else if(combo$SiteNumber[x-1] != combo$SiteNumber[x] & day(combo$StartDateTime[x-1]) == day(combo$StartDateTime[x]) ){
    next
  }else if(combo$midnight_indicator[x] == 0 & is.na(combo$midnight_indicator) == FALSE ){
      combo$days_off[x] <- (as.integer(round(difftime(combo$StartDateTime[x], combo$StartDateTime[x-1], units = "days"))) - 1)
  }
}

##Important Side Note: for complete accuracy, you would need to manually enter combo$days_off[1] -- this type of loop is used multiple times in script !!!

combo$StartTime_difference <- as.numeric(difftime(combo$StartDateTime, combo$SS_StartDateTime, units = "hours"))
combo$EndTime_difference <- as.numeric(difftime(combo$EndDateTime, combo$SS_EndDateTime, units = "hours"))
combo$SS_Position <- NULL
combo <- combo %>% arrange(AssociateID, SortableDate, StartDateTime)


#####CREATE COMBO_ALT (the same dataset without cases where GM did not schedule on a Store Structure dictated workday)
#                   THIS HAS BEEN CREATED SO THAT DAYS OFF METRICS CAN BE CALCULATED -- reason: was already difficult to make, the shifts with NAs throw off the code

#Calculate days off within the week # provided by lubridate # using alternate version of combo dataframe

combo_alt <- combo %>% filter(is.na(StartDateTime) == FALSE)
combo_alt <- combo_alt %>% arrange(AssociateID, SortableDate, StartDateTime)

combo_alt$firstday_wk <- 0
for(jj in 2:nrow(combo_alt)){
  if(is.na(combo_alt$week_in_year[jj-1]) == TRUE | is.na(combo_alt$week_in_year[jj]) == TRUE){
    next
  }
  if(combo_alt$week_in_year[jj-1] != combo_alt$week_in_year[jj]){
    combo_alt$firstday_wk[jj] <- 1
  }
}

combo_alt$lastday_wk <- 0
for(zz in 2:nrow(combo_alt)){
  if(is.na(combo_alt$week_in_year[zz-1]) == TRUE | is.na(combo_alt$week_in_year[zz]) == TRUE){
    next
  }
  
  if(combo_alt$week_in_year[zz-1] != combo_alt$week_in_year[zz]){
    combo_alt$lastday_wk[zz-1] <- 1
  }
}

combo_alt$days_off_in_week <- combo_alt$days_off
for(z in 2:nrow(combo_alt)){
  if(is.na(combo_alt$day_of_week[z]) == TRUE | is.na(combo_alt$firstday_wk[z]) == TRUE | is.na(combo_alt$lastday_wk[z]) == TRUE){
    next
  }
  
  
  if(combo_alt$day_of_week[z] == "Monday" & combo_alt$firstday_wk[z] == 1){ 
      combo_alt$days_off_in_week[z] <- 0
  }
  if(combo_alt$day_of_week[z] == "Tuesday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 1
  }
  if(combo_alt$day_of_week[z] == "Wednesday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 2
  }
  if(combo_alt$day_of_week[z] == "Thursday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 3
  }
  if(combo_alt$day_of_week[z] == "Friday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 4
  }
  if(combo_alt$day_of_week[z] == "Saturday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 5
  }
  if(combo_alt$day_of_week[z] == "Sunday" & combo_alt$firstday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 6
  }
  
  
  if(combo_alt$day_of_week[z] == "Monday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- 6
  }
  if(combo_alt$day_of_week[z] == "Tuesday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z] + 5
  }
  if(combo_alt$day_of_week[z] == "Wednesday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z] + 4
  }
  if(combo_alt$day_of_week[z] == "Thursday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z] + 3
  }
  if(combo_alt$day_of_week[z] == "Friday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z] + 2
  }
  if(combo_alt$day_of_week[z] == "Saturday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z] + 1
  }
  if(combo_alt$day_of_week[z] == "Sunday" & combo_alt$lastday_wk[z] == 1){ 
    combo_alt$days_off_in_week[z] <- combo_alt$days_off_in_week[z]
  }

  
}

combo_alt$midnight_indicator <- NULL
combo_alt$firstday_wk <- NULL
combo_alt$lastday_wk <- NULL

combo$midnight_indicator <- NULL


#eliminate/count double-bookings from data-set
combo_alt$double_booked <- 0
for(z in 1:nrow(combo_alt)){
  if(combo_alt$days_off[z] == -1){
    combo_alt$double_booked[z] <- 1
    combo_alt$days_off_in_week[z] <- 0
  }
}



combo <- combo %>% rename(days_since_last_shift = days_off) %>% arrange(AssociateID, SortableDate, StartDateTime)
combo_alt <- combo_alt %>% rename(days_since_last_shift = days_off) %>% arrange(AssociateID, SortableDate, StartDateTime)


combo$start_seconds <- (hour(combo$StartDateTime)*3600) + (minute(combo$StartDateTime)*60)
combo$end_seconds <- (hour(combo$EndDateTime)*3600) + (minute(combo$EndDateTime)*60)

for(c in 1:nrow(combo)){
  if(combo$end_seconds[c] == 0 & is.na(combo$end_seconds[c]) == FALSE){
    combo$end_seconds[c] <- 84600
  }
}

combo_alt$start_seconds <- (hour(combo_alt$StartDateTime)*3600) + (minute(combo_alt$StartDateTime)*60)
combo_alt$end_seconds <- (hour(combo_alt$EndDateTime)*3600) + (minute(combo_alt$EndDateTime)*60)

for(c in 1:nrow(combo_alt)){
  if(combo_alt$end_seconds[c] == 0 & is.na(combo_alt$end_seconds[c]) == FALSE){
    combo_alt$end_seconds[c] <- 84600
  }
}

c_order <- c("SortableDate", "ScheduledHoursKey",  "WorkingIndicator", "InStoreIndicator", "BaseIndicator", "DistrictNumber", "Division", "SiteNumber", "ScheduleVersion", "WeeksOut", "PayCode", "AssociateID", "JobType", "JobProfile",  "SS_JobDescription", "year", "month", "week_in_year", "day_of_week", "StartDateTime", "EndDateTime", "ScheduleHours", "start_seconds", "end_seconds", "SS_StartDateTime", "SS_EndDateTime", "SS_ScheduledHours", "SS_start_seconds", "SS_end_seconds", "StartTime_difference", "EndTime_difference", "SS_HrsCovered", "days_since_last_shift", "days_off_in_week", "double_booked")
combo_alt <- combo_alt[, c_order]

c_order_2 <- c("SortableDate", "ScheduledHoursKey",  "WorkingIndicator", "InStoreIndicator", "BaseIndicator", "DistrictNumber", "Division", "SiteNumber", "ScheduleVersion", "WeeksOut", "PayCode", "AssociateID", "JobType", "JobProfile",  "SS_JobDescription", "year", "month", "week_in_year", "day_of_week",  "StartDateTime", "EndDateTime", "ScheduleHours", "start_seconds", "end_seconds", "SS_StartDateTime", "SS_EndDateTime", "SS_ScheduledHours", "SS_start_seconds", "SS_end_seconds", "StartTime_difference", "EndTime_difference", "SS_HrsCovered")
combo <- combo[, c_order_2]

combo <- combo %>% arrange(AssociateID, SortableDate, StartDateTime)
combo_alt <- combo_alt %>% arrange(AssociateID, SortableDate, StartDateTime)


##### CALCULATE DAYS OFF PER WEEK PIVOT TABLES -- "scheduled_hrs_pivot_alt" uses Store Structure designated HRs/week (which is known (and doesn't need to be calculated))
#                                                 "scheduled_hrs_pivot" calculates Store Structure designated HRs/week (from "combo")


ss_hrs_week <- read_xlsx("Store_Structure_Schedule_wkly_pivot.xlsx", sheet = 1)

scheduled_hrs_pivot_alt <- combo_alt %>% 
  group_by(AssociateID, SS_JobDescription, year, week_in_year) %>%
  summarize(days_scheduled = (7 - sum(days_off_in_week, na.rm = TRUE)) , days_off = sum(days_off_in_week, na.rm = TRUE), scheduled_hours = sum(ScheduleHours, na.rm = TRUE))
scheduled_hrs_pivot_alt <- inner_join(scheduled_hrs_pivot_alt, ss_hrs_week, by = c("SS_JobDescription"))


scheduled_hrs_pivot <- combo %>% 
  group_by(AssociateID, SS_JobDescription, year, week_in_year) %>%
  summarize(scheduled_hours = sum(ScheduleHours, na.rm = TRUE), SS_scheduled_hours = sum(SS_ScheduledHours, na.rm = TRUE))


store_loc <- read.csv("store_location.csv", stringsAsFactors = FALSE)
names(store_loc)[1] <- "SiteNumber"
names(store_loc)[2] <- "Address"
names(store_loc)[5] <- "State"
store_loc$Additional <- NULL


combo <- merge(combo, store_loc, all.x = TRUE, by = "SiteNumber")
combo_alt <- merge(combo_alt, store_loc, all.x = TRUE, by = "SiteNumber")

combo <- combo %>% arrange(AssociateID, SortableDate, StartDateTime)
combo_alt <- combo_alt %>% arrange(AssociateID, SortableDate, StartDateTime)

#Adding arbitrary StartDateTime and SS_StartDateTimes for Tableau functionality

for(ls in 1:nrow(combo)){
  if(is.na(combo$StartDateTime[ls]) == TRUE){
    combo$StartDateTime[ls] <- as.POSIXct( (paste(substr(combo$SortableDate[ls],1,4), "/", substr(combo$SortableDate[ls],5,6), "/", substr(combo$SortableDate[ls],7,8), " 08:00:00", sep = "")), format="%Y/%m/%d %H:%M") 
    #combo$StartDateTime[ls] <- (combo$StartDateTime[ls], format="%Y/%m/%d %H:%M")
  }
  
  if(is.na(combo$SS_StartDateTime[ls]) == TRUE){
    combo$SS_StartDateTime[ls] <- as.POSIXct( (paste(substr(combo$SortableDate[ls],1,4), "/", substr(combo$SortableDate[ls],5,6), "/", substr(combo$SortableDate[ls],7,8), " 08:00:00", sep = "")), format="%Y/%m/%d %H:%M") 
    }

}

combo <- combo %>% arrange(AssociateID, SortableDate, StartDateTime)
combo_alt <- combo_alt %>% arrange(AssociateID, SortableDate, StartDateTime)


#Optional -- Clean Workspace -- Remove Unnecessary Dataframes





#Metrics -- see documentation -- WILL BE GENERATED IN TABLEAU SO THAT THEY ARE DYNAMIC! -- example of code in R below


#combo$SS_AdheranceRate <-      combo$SS_HrsCovered/combo$SS_ScheduledHours #a
#combo$SS_x <-                  combo$SS_HrsCovered/combo$ScheduledHours #b



# Write Csv -- the end results are dataframes combo & combo_alt -- scheduled_hrs_pivot files may or may not be used within Tableau


# Uncomment these 2 lines below  to genrate the csv file

# write.csv(combo, file = "store_structure.csv", row.names = FALSE)
# write.csv(scheduled_hrs_pivot_alt, file = "ss_employeepromises-version1.csv", row.names = FALSE)

## We decided not to use these, but still kept it for later use if reuired.

## write.csv(combo_alt, file = "store_structure_withdaysoffincluded_knownSSrolesonly.csv", row.names = FALSE)
## write.csv(scheduled_hrs_pivot, file = "ss_employeepromises-version2.csv", row.names = FALSE)