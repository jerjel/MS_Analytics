

# Random Forest Model for Predicting SS_JobDescription
# Training = Mock Store Structure

rm(list = ls())

library(dplyr)
library(randomForest)
library(pROC)
library(gridExtra)
library(ggplot2)

# Mock store structure schedule for training
train <- read.csv("Store_Structure_Schedule_model.csv", stringsAsFactors = FALSE)
names(train)[1] <- "JobType"

for(i in 1:nrow(train)){
  if(train$JobType[i] == "Sales Associate"){
    train$JobType[i] <- "0"
  } else
    if(train$JobType[i] == "Food Associate"){
      train$JobType[i] <- "1"
    }
}

train$JobType <- factor(train$JobType)
train$SS_JobDescription <- factor(train$SS_JobDescription)
train$day_of_week <- factor(train$day_of_week)


# Validation and test on data
df <- read.csv("store_structure.csv", stringsAsFactors = FALSE)

features <- c("AssociateID", "JobType", "JobProfile", "SS_JobDescription", "day_of_week", "ScheduleHours",
              "StartDateTime")
df <- df[complete.cases(df),features]
df$start_time <- substr(df$StartDateTime,12,16)
df$start_time <- gsub(":", "", df$start_time)
df$start_time <- as.integer(df$start_time)
df$StartDateTime <- NULL

convertday <- function(x){
  if(x=="Monday"){
    x<-"1"
  } else
    if(x=="Tuesday"){
      x<-"2"
    } else
      if(x=="Wednesday"){
        x<-"3"
      } else
        if(x=="Thursday"){
          x<-"4"
        } else
          if(x=="Friday"){
            x<-"5"
          } else
            if(x=="Saturday"){
              x<-"6"
            } else
              if(x=="Sunday")
                x<-"7"
}

df$day_of_week <- sapply(df$day_of_week, convertday)
df$day_of_week <- factor(df$day_of_week)
df$SS_JobDescription <- factor(df$SS_JobDescription)

for(i in 1:nrow(df)){
  if(df$JobType[i] == "Sales Associate"){
    df$JobType[i] <- "0"
  } else
    if(df$JobType[i] == "Food Associate"){
      df$JobType[i] <- "1"
    }
}

df$JobType <- factor(df$JobType)
df$SS_JobDescription <- factor(df$SS_JobDescription)

# Validation and testing sets
set.seed(99)
index_vt <- sample(nrow(df), round(nrow(df)*0.7), replace = FALSE)
validate <- df[index_vt,]
validate_labels <- df[index_vt,"SS_JobDescription"]
test <- df[-index_vt,]
test_labels <- df[-index_vt,"SS_JobDescription"]

# Train multiple models to decide best tree count
treenumbers <- data.frame(trees = NA, accuracy = NA, precision = NA, recall = NA, F1_Score = NA)
for(n in c(seq(100,2000, by = 100))){
  set.seed(99)
  model <- randomForest(SS_JobDescription ~ JobType + day_of_week + ScheduleHours + start_time, data = train, ntree = n)
  jobpredict <- predict(model, validate)
  validate$predicted <- jobpredict
  validate$correct <- NA
  for(i in 1:nrow(validate)){
    if(validate$SS_JobDescription[i] == validate$predicted[i]){
      validate$correct[i] <- 1
    } else
      validate$correct[i] <- 0
  }
  rf.matrix <- table(validate$SS_JobDescription, jobpredict)
  sum_precision <- 0
  sum_recall <- 0
  for (i in 1:6) {
    TP <- rf.matrix[i,i]
    FP <- sum(rf.matrix[c(setdiff(1:6,i)),i])
    TN <- sum(rf.matrix[c(setdiff(1:6,i)),c(setdiff(1:6,i))])
    FN <- sum(rf.matrix[i,c(setdiff(1:6,i))])
    
    precision <- TP/(TP + FP)
    recall <- TP/(TP + FN)
    sum_precision <- sum_precision + precision
    sum_recall <- sum_recall + recall
  }
  avg_precision <- sum_precision/6    
  avg_recall <- sum_recall/6     
  f1_score <- (2*(avg_precision*avg_recall)) / (avg_precision + avg_recall)
  accuracy <- sum(validate$correct)/nrow(validate)
  
  df_temp <- c(n, accuracy, avg_precision, avg_recall, f1_score)
  
  treenumbers <- rbind(treenumbers, df_temp)
  print(c(n, accuracy, avg_precision, avg_recall, f1_score))
}
treenumbers <- treenumbers[complete.cases(treenumbers),]

# Plots to choose number of trees
plot(treenumbers$trees, treenumbers$accuracy, xlab = "Number of Trees", ylab = "Accuracy")
lines(treenumbers$trees, treenumbers$accuracy)
title("Random Forest: Mock SS Schedule")
plot(treenumbers$trees, treenumbers$F1_Score, xlab = "Number of Trees", ylab = "F1-Score")
lines(treenumbers$trees, treenumbers$F1_Score)
title("Random Forest: Mock SS Schedule")

# Train model and predict with maximum accuracy and F1-score
set.seed(99)
model <- randomForest(SS_JobDescription ~ JobType + day_of_week + ScheduleHours + start_time, data = train, ntree = 1200)
jobpredict <- predict(model, validate)

# Evaluation metrics by SS_JobDescription
rf.matrix <- table(validate$SS_JobDescription, jobpredict)
sum_precision <- 0
sum_recall <- 0
for (i in 1:6) {
  TP <- rf.matrix[i,i]
  FP <- sum(rf.matrix[c(setdiff(1:6,i)),i])
  TN <- sum(rf.matrix[c(setdiff(1:6,i)),c(setdiff(1:6,i))])
  FN <- sum(rf.matrix[i,c(setdiff(1:6,i))])
  
  precision <- TP/(TP + FP)
  recall <- TP/(TP + FN)
  sum_precision <- sum_precision + precision
  sum_recall <- sum_recall + recall
}
avg_precision <- sum_precision/6    
avg_recall <- sum_recall/6     
f1_score <- (2*(avg_precision*avg_recall)) / (avg_precision + avg_recall)
accuracy <- sum(validate$correct)/nrow(validate)

# ROC curves by SS_JobDescription with AUC
validate$is_Assistant_Manager <- NA
validate$is_Food_Manager <- NA
validate$is_General_Manager <- NA
validate$is_Overnight_Shift_Lead_1 <- NA
validate$is_Overnight_Shift_Lead_2 <- NA
validate$`is_Store_Associate - Food` <- NA

for(i in 1:nrow(validate)){
  if(validate$SS_JobDescription[i] == "Assistant Manager"){
    validate$is_Assistant_Manager[i] <- 1
  } else
    validate$is_Assistant_Manager[i] <- 0
  if(validate$SS_JobDescription[i] == "Food Manager"){
    validate$is_Food_Manager[i] <- 1
  } else
    validate$is_Food_Manager[i] <- 0
  if(validate$SS_JobDescription[i] == "General Manager"){
    validate$is_General_Manager[i] <- 1
  } else
    validate$is_General_Manager[i] <- 0
  if(validate$SS_JobDescription[i] == "Overnight Shift Lead 1"){
    validate$is_Overnight_Shift_Lead_1[i] <- 1
  } else
    validate$is_Overnight_Shift_Lead_1[i] <- 0
  if(validate$SS_JobDescription[i] == "Overnight Shift Lead 2"){
    validate$is_Overnight_Shift_Lead_2[i] <- 1
  } else
    validate$is_Overnight_Shift_Lead_2[i] <- 0
  if(validate$SS_JobDescription[i] == "Store Associate - Food"){
    validate$`is_Store_Associate - Food`[i] <- 1
  } else
    validate$`is_Store_Associate - Food`[i] <- 0
}

validate$predicted_Assistant_Manager <- NA
validate$predicted_Food_Manager <- NA
validate$predicted_General_Manager <- NA
validate$predicted_Overnight_Shift_Lead_1 <- NA
validate$predicted_Overnight_Shift_Lead_2 <- NA
validate$`predicted_Store_Associate - Food` <- NA

for(i in 1:nrow(validate)){
  if(validate$predicted[i] == "Assistant Manager"){
    validate$predicted_Assistant_Manager[i] <- 1
  } else
    validate$predicted_Assistant_Manager[i] <- 0
  if(validate$predicted[i] == "Food Manager"){
    validate$predicted_Food_Manager[i] <- 1
  } else
    validate$predicted_Food_Manager[i] <- 0
  if(validate$predicted[i] == "General Manager"){
    validate$predicted_General_Manager[i] <- 1
  } else
    validate$predicted_General_Manager[i] <- 0
  if(validate$predicted[i] == "Overnight Shift Lead 1"){
    validate$predicted_Overnight_Shift_Lead_1[i] <- 1
  } else
    validate$predicted_Overnight_Shift_Lead_1[i] <- 0
  if(validate$predicted[i] == "Overnight Shift Lead 2"){
    validate$predicted_Overnight_Shift_Lead_2[i] <- 1
  } else
    validate$predicted_Overnight_Shift_Lead_2[i] <- 0
  if(validate$predicted[i] == "Store Associate - Food"){
    validate$`predicted_Store_Associate - Food`[i] <- 1
  } else
    validate$`predicted_Store_Associate - Food`[i] <- 0
}


par(pty = "s")
# ROC Curves (Receiver Operating Characteristic)
roc(validate$is_Assistant_Manager, validate$predicted_Assistant_Manager, plot = T, legacy.axes = T,
    xlab="False Positive Rate", ylab="True Positive Rate", col="#C20000", lwd=4, print.auc=T)
plot.roc(validate$is_Food_Manager, validate$predicted_Food_Manager, col="#C26A00", lwd=4,
         print.auc=T, add=T, print.auc.y=.45)
plot.roc(validate$is_General_Manager, validate$predicted_General_Manager, col="#C2A800", lwd=4,
         print.auc=T, add=T, print.auc.y=.4)
plot.roc(validate$is_Overnight_Shift_Lead_1, validate$predicted_Overnight_Shift_Lead_1, col="#00C200", lwd=4,
         print.auc=T, add=T, print.auc.y=.35)
plot.roc(validate$is_Overnight_Shift_Lead_2, validate$predicted_Overnight_Shift_Lead_2, col="#0067C2", lwd=4,
         print.auc=T, add=T, print.auc.y=.3)
plot.roc(validate$`is_Store_Associate - Food`, validate$`predicted_Store_Associate - Food`, col="#5E00C2", lwd=4,
         print.auc=T, add=T, print.auc.y=.25)

legend("bottomright", legend=c("Assistant Manager", "Food Manager", "General Manager", "Overnight Shift Lead 1",
                               "Overnight Shift Lead 2", "Store Associate - Food"),
       col=c("#C20000", "#C26A00", "#C2A800", "#00C200", "#0067C2", "#5E00C2"), lwd=4, cex = .7, xjust = .5)
title("Random Forest: Train = Mock SS Schedule, Accuracy = .83", line = 3.3)
title("SS_JobDescription ~ JobType + day_of_week + ScheduleHours + start_time", line = 2.3)
par(pty = "m")


# Accuracy by AssociateID
assoc_accuracy <- validate %>%
  group_by(AssociateID) %>%
  summarize(accuracy = (sum(correct)/length(AssociateID)))
assoc_accuracy <- assoc_accuracy[order(assoc_accuracy$accuracy),]
assoc_accuracy$AssociateID <- factor(assoc_accuracy$AssociateID, levels = assoc_accuracy$AssociateID)

p <- ggplot(assoc_accuracy, aes(x=AssociateID, y=accuracy, fill = accuracy)) +
  geom_col() +
  ggtitle("Random Forest: Train = Mock SS Schedule", subtitle = "Accuracy by AssociateID") +
  theme(axis.text.x = element_text(angle = 90, size = 5, vjust = .5),
        axis.text.y = element_text(size = 6),
        axis.title = element_text(size = 12),
        legend.position = "none",
        panel.grid = element_blank(),
        panel.background = element_rect(fill = "white"))
p

# ggsave("RF_MockSS_AssociateID.png", p, width = 16, height = 9, units = "cm")

