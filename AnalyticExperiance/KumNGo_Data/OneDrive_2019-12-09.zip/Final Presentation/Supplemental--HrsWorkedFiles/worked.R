#KUM & GO STORE STRUCTURE PROJECT -- U IOWA MSBA

#WORKED HOURS TO SCHEDULED HOURS -- COMBINED CLEANING SCRIPT

#####

#PACKAGES

library(tidyverse)
library(lubridate)
library(dplyr)
library(tidyr)

#####

#ASSUMPTIONS

#PayCode = "Hourly Pay"
#WorkingIndicator = 1
#ScheduleVersion = 2

#####
#sometimes the read.csv will read StartTimeDate in the desired date format; but then, columns are unnamed (use this code in that case)

# scheduled <- read.csv("20190904_factScheduledHours_District7.csv", stringsAsFactors = FALSE)
# 
# col_names <- c("ScheduledHoursKey", 	"LogKey",	"StartDateKey", 	"EndDateKey",	"BookDateKey",	"SiteKey",	"SiteCurrentKey", "SWHAlternateKey",
#                "CostCenterKey",	"StartTimeKey",	"EndTimeKey",	"AssociateKey",	"KronosSite",	"SiteNumber",	"AssociateID",	"CostCenter",
#                "ScheduleVersion",	"WeeksOut",	"JobType",	"PayCode",	"StartDate",	"StartTime",	"StartDateTime",	"EndDate",	"EndTime",
#                "EndDateTime",	"BookDate",	"ScheduleHours",	"ExtractDate",	"SourceID",	"SourceConfigID",	"OriginalSourceConfigID",	"CreateDate",
#                "WorkingIndicator",	"InStoreIndicator",	"BaseIndicator",	"DistrictNumber",	"Division")
# 
# for(a in 1:ncol(scheduled)){
#   names(scheduled)[a] <- col_names[a]
# }

#####


scheduled <- read.csv("2019-11-15_factScheduledHours_District7.csv", stringsAsFactors = FALSE)

#StartTimeDate is not in POSIXct format -- using alt key to correct:

scheduled_altkey <- scheduled$ScheduledHoursAlternateKey
scheduled_altkey <- unlist(strsplit(scheduled_altkey, "|", fixed = TRUE))

date <- scheduled_altkey[seq(3,length(scheduled_altkey),by = 8)]
time <- scheduled_altkey[seq(4,length(scheduled_altkey),by = 8)]

#Derive Year, Month, Day, Hour, and Minute from worked_altkey list

start_hour <- c()
start_minute <- c()

j <- 1

for(i in 1:nrow(scheduled)){
  
  if(nchar(time[i]) == 5){
    
    start_hour[j] <- substr(time[i],1,1)
    start_minute[j] <- substr(time[i],2,3)
    
    j <- j + 1
    
  } else {
    
    start_hour[j] <- substr(time[i],1,2)
    start_minute[j] <- substr(time[i],3,4)
    
    j <- j + 1
  }}


year <- as.integer(substr(date,1,4))
month <- as.integer(substr(date,5,6))
day <- as.integer(substr(date,7,8))

scheduled$StartTime <- paste(start_hour, ":", start_minute, ":00", sep = "")
scheduled$StartDateTime <- paste(year, "/", month, "/", day, " ", scheduled$StartTime,sep = "")

scheduled$StartDateTime <- as.POSIXct(scheduled$StartDateTime,format="%Y/%m/%d %H:%M")

##same process for EndTimeDate

date_end <- scheduled_altkey[seq(5,length(scheduled_altkey),by = 8)]
time_end <- scheduled_altkey[seq(6,length(scheduled_altkey),by = 8)]

#Derive Year, Month, Day, Hour, and Minute from worked_altkey list

start_hour_end <- c()
start_minute_end <- c()

k <- 1

for(m in 1:nrow(scheduled)){
  
  if(nchar(time_end[m]) == 5){
    
    start_hour_end[k] <- substr(time_end[m],1,1)
    start_minute_end[k] <- substr(time_end[m],2,3)
    
    k <- k + 1
    
  } else {
    
    start_hour_end[k] <- substr(time_end[m],1,2)
    start_minute_end[k] <- substr(time_end[m],3,4)
    
    k <- k + 1
  }}


year_end <- as.integer(substr(date_end,1,4))
month_end <- as.integer(substr(date_end,5,6))
day_end <- as.integer(substr(date_end,7,8))

scheduled$EndTime <- paste(start_hour_end, ":", start_minute_end, ":00", sep = "")
scheduled$EndDateTime <- paste(year_end, "/", month_end, "/", day_end, " ", scheduled$EndTime,sep = "")

scheduled$EndDateTime <- as.POSIXct(scheduled$EndDateTime,format="%Y/%m/%d %H:%M")

#earlier versions of code ran on dataframe that did not have ScheduledHoursAlternateKey column...thus, removing now
scheduled$ScheduledHoursAlternateKey <- NULL


#####

scheduled$Division <- factor(scheduled$Division)
scheduled$DistrictNumber <- factor(scheduled$DistrictNumber)
scheduled$JobType <- factor(scheduled$JobType)
scheduled$BaseIndicator <- factor(scheduled$BaseIndicator)
scheduled$PayCode <- factor(scheduled$PayCode)
scheduled$WorkingIndicator <- factor(scheduled$WorkingIndicator)
scheduled$DistrictNumber <- factor(scheduled$DistrictNumber)
scheduled$AssociateID <- factor(scheduled$AssociateID)
scheduled$CostCenter <- factor(scheduled$CostCenter)
scheduled$SiteNumber <- factor(scheduled$SiteNumber)
scheduled$InStoreIndicator <- factor(scheduled$InStoreIndicator)
scheduled$WeeksOut <- factor(scheduled$WeeksOut)
scheduled$ScheduleVersion <- factor(scheduled$ScheduleVersion)

# scheduled$ScheduleHours <- factor(scheduled$ScheduleHours)

#scheduled$StartDateTime <- as.POSIXct(scheduled$StartDateTime)
#scheduled$EndDateTime <- as.POSIXct(scheduled$EndDateTime)
#scheduled$CreateDate <- as.POSIXct(scheduled$CreateDate)
#scheduled$ExtractDate <- as.POSIXct(scheduled$ExtractDate)

#####

scheduled$day_of_week <- factor(weekdays.POSIXt(scheduled$StartDateTime))
scheduled$month <- factor(months.POSIXt(scheduled$StartDateTime))
scheduled$start_hour <- hour(scheduled$StartDateTime)
scheduled <- filter(scheduled, ScheduleVersion == 2, WorkingIndicator == 1, PayCode == "Hourly Pay")
#
scheduled_clean <- scheduled[c("AssociateID" ,  "ScheduledHoursKey", "WorkingIndicator", "InStoreIndicator", "BaseIndicator",   "DistrictNumber",
                               "Division" ,"SiteNumber","ScheduleVersion", "WeeksOut","JobType","PayCode", "month", "day_of_week", 
                               "JobProfile", "StartDateTime", "EndDateTime","ScheduleHours")]

##########

worked <- read.csv("2019-11-15_factWorkedHours_District7_Overnight.csv", stringsAsFactors = FALSE, header = FALSE)

col_names_2 <- c("WorkedHoursKey", "WorkedHoursAlternateKey",	"LogKey",	"StartDateKey", 	"EndDateKey",	"BookDateKey",	"SiteKey",	"SiteCurrentKey", "SiteFinancialAlternateKey", "SWHAlternateKey",
                "CostCenterKey",	"StartTimeKey",	"EndTimeKey", "AssociateKey", "KronosSite", "SiteNumber",	"AssociateID",	"CostCenter",
                "JobType",	"BasePayCode",	"StartDate",	"StartTime",	"StartDateTime",	"EndDate",	"EndTime",
                "EndDateTime",	"BookDate", "OvernightDate",	"WorkedHours", "WorkingIndicator", "TrainingIndicator", "ShiftPremiumIndicator", "Premium50Indicator",
                "Premium100Indicator", "OvertimeIndicator", "OT.FLSAIndicator", "OT.COIndicator",	"SourceID",	"SourceConfigID",	"OriginalSourceConfigID", "CreateDate", "InStoreIndicator", 
                "DistrictNumber", "Division", "JobProfile")

 for(a in 1:ncol(worked)){
   names(worked)[a] <- col_names_2[a]
 }

worked_altkey <- worked$WorkedHoursAlternateKey
worked_altkey <- unlist(strsplit(worked_altkey, "|", fixed = TRUE))

date <- worked_altkey[seq(3,length(worked_altkey),by = 5)]
time <- worked_altkey[seq(4,length(worked_altkey),by = 5)]

#Derive Year, Month, Day, Hour, and Minute from worked_altkey list

start_hour <- c()
start_minute <- c()

j <- 1

for(i in 1:nrow(worked)){
  
  if(nchar(time[i]) == 5){
    
    start_hour[j] <- substr(time[i],1,1)
    start_minute[j] <- substr(time[i],2,3)
    
    j <- j + 1
    
  } else {
    
    start_hour[j] <- substr(time[i],1,2)
    start_minute[j] <- substr(time[i],3,4)
    
    j <- j + 1
  }}


year <- as.integer(substr(date,1,4))
month <- as.integer(substr(date,5,6))
day <- as.integer(substr(date,7,8))

revised_start_time <- paste(start_hour, ":", start_minute, sep = "")

worked <- cbind(worked, year,month, day, start_hour, start_minute, revised_start_time)
worked$StartDate <- paste(worked$year, worked$month,worked$day,sep = "/")

#####

# Creating a start date and time stamp, converting it to a POSIXct object

worked$StartDateTime <-  paste(worked$StartDate, worked$revised_start_time, sep = " ")
worked$StartDateTime <- as.POSIXct(worked$StartDateTime,format="%Y/%m/%d %H:%M")

#####

# Derive the end time of a shift

worked$shiftSeconds <- as.numeric(worked$WorkedHours)*60*60
worked$shiftSeconds_char <- as.character(worked$shiftSeconds)


##the following code is used to fix rounding error that occurs when transforming work hours -> work hours in seconds

for(k in 1:nrow(worked)){
  
  if( (substr( (worked$shiftSeconds_char[k]), (nchar(worked$shiftSeconds_char[k]) ), (nchar(worked$shiftSeconds_char[k])))) == "2" ) {
    worked$shiftSeconds[k] <- (worked$shiftSeconds[k] - 12)
  }
  
  if( (substr( (worked$shiftSeconds_char[k]), (nchar(worked$shiftSeconds_char[k]) ), (nchar(worked$shiftSeconds_char[k])))) == "8" ) {
    worked$shiftSeconds[k] <- (worked$shiftSeconds[k] + 12)
  }
}


# Using the lubridate package worked hours is added to the start time of the shift

worked$EndDateTime <- worked$StartDateTime+seconds(worked$shiftSeconds)
worked$day_of_week <- factor(weekdays.POSIXt(worked$StartDateTime))
worked$shift_minutes_worked <- worked$shiftSeconds / 60

#above line needs to stay as numeric data type

#####

# Formatting/Additional R Cleanup

# columns originally included in data

worked$Division <- factor(worked$Division)
worked$JobType <- factor(worked$JobType)
worked$BasePayCode <- factor(worked$BasePayCode)
worked$WorkingIndicator <- factor(worked$WorkingIndicator)
worked$TrainingIndicator <- factor(worked$TrainingIndicator)
worked$ShiftPremiumIndicator <- factor(worked$ShiftPremiumIndicator)
worked$Premium50Indicator <- factor(worked$Premium50Indicator)
worked$Premium100Indicator <- factor(worked$Premium100Indicator)
worked$OvertimeIndicator <- factor(worked$OvertimeIndicator)
worked$OT.FLSAIndicator <- factor(worked$OT.FLSAIndicator)
#worked$OT.CODailyIndicator <- factor(worked$OT.CODailyIndicator)
worked$DistrictNumber <- factor(worked$DistrictNumber)
worked$AssociateID <- factor(worked$AssociateID)
worked$CostCenter <- factor(worked$CostCenter)
worked$DistrictNumber <- factor(worked$DistrictNumber)
worked$SiteNumber <- factor(worked$SiteNumber)
worked$InStoreIndicator <- factor(worked$InStoreIndicator)
worked$KronosSite <- factor(worked$KronosSite)
worked$year <- factor(worked$year)

# Edit the month column to add names

worked$month <- factor(worked$month)

if((nlevels(worked$month)) == 9) {
  
  levels(worked$month) <- c("January", "February", "March", "April", "May", "June", "July", "August", "December")
} else if((nlevels(worked$month)) == 10) {
  
  levels(worked$month) <- c("January", "February", "March", "April", "May", "June", "July", "August", "September", "December")
} else if((nlevels(worked$month)) == 11) {
  
  levels(worked$month) <- c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "December")
} else if((nlevels(worked$month)) == 12) {
  
  levels(worked$month) <- c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
}

# delete any (now) uncessary columns      

worked$shiftSeconds <- NULL
worked$shiftSeconds_char <- NULL
worked$revised_start_time <- NULL
worked$start_hour <- NULL
worked$start_minute <- NULL

############# FILTERING

#feel free to rename below dataframe

worked <- filter(worked, WorkingIndicator == 1, BasePayCode == "Hourly Pay")
worked_clean <- worked[c("WorkedHoursKey", "WorkingIndicator", "TrainingIndicator", "ShiftPremiumIndicator", "Premium50Indicator","Premium100Indicator",  
                         "OvertimeIndicator", "OT.FLSAIndicator", "OT.COIndicator", "DistrictNumber", "Division", "JobProfile",          
                          "SiteNumber",  "AssociateID", "JobType", "BasePayCode", "StartDateTime", "EndDateTime",         
                          "WorkedHours", "day_of_week", "shift_minutes_worked")]

############

worked_clean <- filter(worked_clean, !is.na(StartDateTime), !is.na(EndDateTime))
worked_clean <- worked_clean[order(worked_clean$AssociateID, worked_clean$StartDateTime), ]
worked_clean$time_in_between_mins <- 0

for(i in 2:nrow(worked_clean)){
  if(worked_clean$AssociateID[i] != worked_clean$AssociateID[i-1]){
    next
  }
  
  if( (month(worked_clean$StartDateTime[i]) == month(worked_clean$EndDateTime[i - 1])) & (day(worked_clean$StartDateTime[i]) == day(worked_clean$EndDateTime[i - 1])) ) {
    worked_clean$time_in_between_mins[i] <- difftime(worked_clean$StartDateTime[i], worked_clean$EndDateTime[i - 1], units = "mins")
  }
}

worked_clean$break_longer_than_15 <- 0

for(c in 1:nrow(worked_clean)){
  if(worked_clean$time_in_between_mins[c] >= 15){
    worked_clean$break_longer_than_15[c] <- 1
  }
}

worked_clean$SortableDate <- factor(paste(as.character(month(worked_clean$StartDateTime)), as.character(day(worked_clean$StartDateTime)), as.character(year(worked_clean$StartDateTime)), sep = ""))
scheduled_clean$SortableDate <- factor(paste(as.character(month(scheduled_clean$StartDateTime)), as.character(day(scheduled_clean$StartDateTime)), as.character(year(scheduled_clean$StartDateTime)), sep = ""))

num_shifts_scheduled <- scheduled_clean %>%
  group_by(SortableDate, AssociateID) %>%
  summarize(num_shifts_sch = n(), total_sch_hrs = sum(ScheduleHours)) %>%
  arrange(AssociateID)

worked_clean <- merge(worked_clean, num_shifts_scheduled, by = c("SortableDate", "AssociateID"), all.x = TRUE)
worked_clean$total_sch_hrs <- NULL

for(bb in 1:nrow(worked_clean)){
  if(is.na(worked_clean$num_shifts[bb])){
    worked_clean$num_shifts[bb] <- 0
  }
}

for(cc in 1:nrow(worked_clean)){
  if((worked_clean$num_shifts[cc] > 1) | (worked_clean$time_in_between_mins[cc] > 120) | (worked_clean$time_in_between_mins[cc] < 0) ){
    worked_clean$time_in_between_mins[cc] <- 0
    worked_clean$break_longer_than_15[cc] <- 0
  }
}


### dplyr approach

number_of_clockins   <- worked_clean %>%
  group_by(SortableDate, AssociateID) %>%
  summarize(num_clockins = n(), total_wrk_hrs = sum(WorkedHours), total_break_min = sum(time_in_between_mins), breaks_over_15 = sum(break_longer_than_15)) %>%
  arrange(AssociateID)


worked_clean <- merge(worked_clean, number_of_clockins, by = c("SortableDate", "AssociateID"), all.x = TRUE)
scheduled_clean <- merge(scheduled_clean, num_shifts_scheduled, by = c("SortableDate", "AssociateID"), all.x = TRUE)

worked_clean <- worked_clean %>% spread(num_clockins, StartDateTime)
scheduled_clean <- scheduled_clean %>% spread(num_shifts_sch, StartDateTime)

names(worked_clean)[29] <- "one_clockin"
names(worked_clean)[30] <- "two_clockins"
names(worked_clean)[31] <- "three_clockins"
names(worked_clean)[32] <- "four_clockins"
names(worked_clean)[33] <- "five_clockins"
names(worked_clean)[34] <- "six_clockins"
names(worked_clean)[35] <- "seven_clockins"
names(worked_clean)[36] <- "eight_clockins"

names(scheduled_clean)[20] <- "one_shift"
names(scheduled_clean)[21] <- "two_shifts"
names(scheduled_clean)[22] <- "three_shifts"

scheduled_clean$daily_shift_num <- 1

scheduled_clean <- scheduled_clean[order(scheduled_clean$AssociateID, scheduled_clean$EndDateTime), ]

a <- 1

for(jj in 2:nrow(scheduled_clean)){
  
  if( (is.na(scheduled_clean$one_shift[jj]) == FALSE) | (scheduled_clean$AssociateID[jj] != scheduled_clean$AssociateID[jj - 1]) | (scheduled_clean$SortableDate[jj] != scheduled_clean$SortableDate[jj - 1])){
    a <- 1
    next
  }
  else{
    a <- a + 1
    scheduled_clean$daily_shift_num[jj] <- a
  }
  
}

worked_clean <- worked_clean %>% arrange(AssociateID, EndDateTime)

worked_clean$daily_clockin <- 1
b <- 1

for(kk in 2:nrow(worked_clean)){
  
  if( (is.na(worked_clean$one_clockin[kk]) == FALSE) | (worked_clean$AssociateID[kk] != worked_clean$AssociateID[kk - 1]) | (worked_clean$SortableDate[kk] != worked_clean$SortableDate[kk - 1])){
    b <- 1
    next
  }
  else{
    b <- b + 1
    worked_clean$daily_clockin[kk] <- b
  }
  
}

scheduled_clean <- scheduled_clean %>% gather( SHIFT, START_TIME, one_shift:three_shifts )
scheduled_clean <- scheduled_clean[complete.cases(scheduled_clean), ]
scheduled_clean <- scheduled_clean[order(scheduled_clean$AssociateID, scheduled_clean$EndDateTime), ]
scheduled_clean$SHIFT <- NULL
#
scheduled_clean <- scheduled_clean %>% rename(Month = month, DayOfWeek = day_of_week, DailyTotalScheduleHours = total_sch_hrs, DailyShiftNumber = daily_shift_num, StartDateTime = START_TIME)

worked_clean <- worked_clean %>% gather(CLOCKIN, START_TIME, one_clockin:eight_clockins )
worked_clean <- worked_clean[complete.cases(worked_clean), ]
worked_clean <- worked_clean[order(worked_clean$AssociateID, worked_clean$EndDateTime), ]
worked_clean$CLOCKIN <- NULL

worked_clean$num_shifts <- NULL
#
worked_clean <- worked_clean %>% rename(PayCode = BasePayCode, DayOfWeek = day_of_week, MinsBetweenClockins = time_in_between_mins,  
                                        MinsBetweenOver15Indicator = break_longer_than_15, TotalDailyShiftsScheduled = num_shifts_sch, 
                                        TotalDailyHoursWorked = total_wrk_hrs, TotalDailyMinsBetweenClockins = total_break_min, 
                                        NumberOfDailyClockins = daily_clockin, TotalDailyBreaksOver15 = breaks_over_15, 
                                        StartDateTime = START_TIME)

###combine
#
worked_combined <- worked_clean[c("SortableDate", "WorkedHoursKey", "WorkingIndicator", "DistrictNumber", "Division", "PayCode", "SiteNumber",  "AssociateID",
                                  "JobType", "JobProfile", "DayOfWeek", "StartDateTime", "EndDateTime", "WorkedHours", "TotalDailyShiftsScheduled", "TotalDailyHoursWorked",
                                   "TotalDailyBreaksOver15", "NumberOfDailyClockins", "MinsBetweenClockins", "MinsBetweenOver15Indicator")]

worked_combined$ScheduledHoursKey <- NA
worked_combined$DailyTotalScheduleHours <- NA
worked_combined$ScheduledDailyShiftNumber <- NA
worked_combined$DailyShiftNumber <- NA
worked_combined$Table <- "worked"

scheduled_combined <- scheduled_clean[c("SortableDate", "ScheduledHoursKey", "WorkingIndicator", "DistrictNumber", "Division",  "PayCode", "SiteNumber",  "AssociateID",
                                        "JobType", "JobProfile", "DayOfWeek", "StartDateTime", "EndDateTime", "ScheduleHours",  "DailyTotalScheduleHours", "DailyShiftNumber")]

scheduled_combined$Table <- "scheduled"
scheduled_combined$NumberOfDailyClockins <- 0
scheduled_combined$MinsBetweenClockins <- 0
scheduled_combined$MinsBetweenOver15Indicator <- NA
scheduled_combined$TotalDailyShiftsScheduled <- 0
scheduled_combined$TotalDailyHoursWorked <- NA
scheduled_combined$TotalDailyBreaksOver15 <- 0
scheduled_combined$WorkedHoursKey <- NA
scheduled_combined$ScheduledDailyShiftNumber <- NA

#ERRORS AROUND HERE*

#reordered columns to match, also removed total hours (we can use summation to calculate this)

worked_combined <- worked_combined[c("SortableDate", "WorkedHoursKey", "ScheduledHoursKey", "WorkingIndicator", "DistrictNumber", "Division", "PayCode", "SiteNumber",  "AssociateID", "Table",
                                  "JobType", "JobProfile", "DayOfWeek", "StartDateTime", "EndDateTime", "WorkedHours", "ScheduledDailyShiftNumber","DailyTotalScheduleHours", "DailyShiftNumber", 
                                  "TotalDailyShiftsScheduled", "TotalDailyHoursWorked", "TotalDailyBreaksOver15", "NumberOfDailyClockins", "MinsBetweenClockins", "MinsBetweenOver15Indicator")]

scheduled_combined <- scheduled_combined[c("SortableDate", "WorkedHoursKey", "ScheduledHoursKey", "WorkingIndicator",  "DistrictNumber", "Division", "PayCode", "SiteNumber",  "AssociateID", "Table",
                                        "JobType", "JobProfile", "DayOfWeek", "StartDateTime", "EndDateTime", "ScheduleHours", "ScheduledDailyShiftNumber","DailyTotalScheduleHours", "DailyShiftNumber", 
                                        "TotalDailyShiftsScheduled", "TotalDailyHoursWorked", "TotalDailyBreaksOver15", "NumberOfDailyClockins", "MinsBetweenClockins", "MinsBetweenOver15Indicator")]

worked_combined <- rename(worked_combined, Hours = WorkedHours)
scheduled_combined <- rename(scheduled_combined, Hours = ScheduleHours)

scheduled_combined$SortableDate <- NA

for(i in 1:nrow(scheduled_combined)){
  a <- month(scheduled_combined$StartDateTime[i])
  if(a < 10){
    a <- paste("0", as.character(a), sep = "")
  } else {
    a <- as.character(a)
  }
  b <- day(scheduled_combined$StartDateTime[i])
  if(b < 10){
    b <- paste("0", as.character(b), sep = "")
  } else {
    b <- as.character(b)
  }
  scheduled_combined$SortableDate[i] <- paste(as.character(year(scheduled_combined$StartDateTime[i])), a, b, sep ="")
}

worked_combined$SortableDate <- NA

for(i in 1:nrow(worked_combined)){
  a <- month(worked_combined$StartDateTime[i])
  if(a < 10){
    a <- paste("0", as.character(a), sep = "")
  } else {
    a <- as.character(a)
  }
  b <- day(worked_combined$StartDateTime[i])
  if(b < 10){
    b <- paste("0", as.character(b), sep = "")
  } else {
    b <- as.character(b)
  }
  worked_combined$SortableDate[i] <- paste(as.character(year(worked_combined$StartDateTime[i])), a, b, sep ="")
}


num_shifts_scheduled <- scheduled_combined %>%
  group_by(SortableDate, AssociateID) %>%
  summarize(TotalShiftsOrClockins = n()) %>%
  arrange(AssociateID)

number_of_clockins   <- worked_combined %>%
  group_by(SortableDate, AssociateID) %>%
  summarize(TotalShiftsOrClockins = n()) %>%
  arrange(AssociateID)


scheduled_combined <- merge(scheduled_combined, num_shifts_scheduled, by = c("SortableDate", "AssociateID"), all.x = TRUE)
scheduled_combined$TotalDailyShiftsScheduled <- scheduled_combined$TotalShiftsOrClockins
scheduled_combined$ScheduledDailyShiftNumber <- scheduled_combined$DailyShiftNumber

worked_combined <- merge(worked_combined, number_of_clockins, by = c("SortableDate", "AssociateID"), all.x = TRUE)

combined <- rbind(scheduled_combined, worked_combined)
combined$Table <- factor(combined$Table)
combined$ScheduledDailyShiftNumber <- as.integer(combined$ScheduledDailyShiftNumber)
combined$NumberOfDailyClockins <- as.integer(combined$NumberOfDailyClockins)
#combined$MinsBetweenOver15Indicator <- factor(combined$MinsBetweenOver15Indicator)
combined$SortableDate <- as.integer(combined$SortableDate)

## THE ORDER/SORT SHOULD BE GOOD -- COULD CREATE A FOR-LOOP TO CALCULATE HOURS COVERED/UNCOVERED -- VERY CLOSE ##

combined <- combined[order(combined$AssociateID, combined$SortableDate, combined$Table), ]

#############################

hrs_covered_calc <- function(s_start, s_end, w_start, w_end) {
  
  if(w_start >= s_end){
    y <- 0
    return(y)
    break
  }
  
  if(w_end <= s_start){
    y <- 0
    return(y)
    break
  }
  
  if(w_start >= s_start & w_end <= s_end){
    y <- as.numeric(difftime(w_end, w_start, units = "hours"))
    return(y)
    break
  } 
  
  if(w_start <= s_start & w_end <= s_end){
    y <- as.numeric(difftime(w_end, s_start, units = "hours"))
    return(y)
    break
  }
  
  if(w_start >= s_start & w_end >= s_end){
    y <- as.numeric(difftime(s_end, w_start, units = "hours"))
    return(y)
    break
  }
  
  if(w_start <= s_start & w_end >= s_end){
    y <- as.numeric(difftime(s_end, s_start, units = "hours"))
    return(y)
    break
  }
}



combined$ShiftHoursCovered <- NA

for(i in 1:(nrow(combined)-1)){

  if(combined$Table[i] == "worked"){
    next
  }

  a <- combined$TotalShiftsOrClockins[i]
  b <- combined$ScheduledDailyShiftNumber[i]
  w <- combined$TotalShiftsOrClockins[i + ((a - b) + 1)]

  if(combined$Table[i + ((a - b) + 1)] == "scheduled"){
          combined$ShiftHoursCovered[i] <- 0
          next
   }

  n <- 0

  for(k in 1:w){
    if(combined$SiteNumber[i] != combined$SiteNumber[i + (a - b) + k]){
      next
    }
    n  <- hrs_covered_calc(combined$StartDateTime[i], combined$EndDateTime[i], combined$StartDateTime[i + (a - b) + k], combined$EndDateTime[i + (a - b) + k]) + n
  }
    combined$ShiftHoursCovered[i] <- n
}

#combined$PercentageShiftCovered <- combined$ShiftHoursCovered/combined$Hours

hrs_wk_by_site <- combined %>%
              filter(Table == "worked") %>%
              group_by(SortableDate, AssociateID, SiteNumber) %>%
              summarise(TotalHrsWorked = sum(Hours))
              

hrs_wk_by_site$Table <- "scheduled"
hrs_wk_by_site <- hrs_wk_by_site[order(hrs_wk_by_site$AssociateID, hrs_wk_by_site$SortableDate), ]

combined_b <- merge(combined, hrs_wk_by_site, by = c("SortableDate", "AssociateID", "Table", "SiteNumber"), all.x = TRUE)
#combined$HoursWorkedToHoursScheduled <- combined$TotalHrsWorked/combined$Hours

###########

#combined$MinsBetweenOver15Indicator <- as.integer(combined$MinsBetweenOver15Indicator)

wrk <- combined_b %>%
        filter(Table == "worked") %>%
        group_by(AssociateID, SortableDate, SiteNumber) %>%
        summarise(TotalClockins = mean(TotalShiftsOrClockins), AvgMinsBetweenClockins = mean(MinsBetweenClockins), BreaksLongerThan15min = sum(MinsBetweenOver15Indicator)) %>%
        arrange(AssociateID, SortableDate)

sch <- combined_b %>%
  filter(Table == "scheduled") %>%
  group_by(AssociateID, SortableDate, SiteNumber) %>%
  summarise(NumShifts = mean(TotalShiftsOrClockins), HrsScheduled = sum(Hours), HrsCovered = sum(ShiftHoursCovered), HrsWorked = mean(TotalHrsWorked)) %>%
  rename(TotalShiftsWorked = NumShifts) %>%
  arrange(AssociateID, SortableDate)

#this results in a smaller number of shifts than in the original scheduled dataset -- due to 2 shifts being scheduled in the same site location 

combined_x <- merge(sch, wrk, by = c("AssociateID", "SortableDate", "SiteNumber"), all.x = TRUE)
combined_x <- combined_x[order(combined_x$AssociateID, combined_x$SortableDate), ]

cmb <- combined[, c("SortableDate", "AssociateID", "Division", "DistrictNumber", "PayCode", "SiteNumber", "WorkedHoursKey",
                    "ScheduledHoursKey", "Table", "JobProfile", "TotalShiftsOrClockins" )]

cmb <- cmb %>% filter(Table == "scheduled") %>% rename(TotalShiftsWorked = TotalShiftsOrClockins)
cmb$Table <- NULL
cmb <- distinct(cmb)

combined_x <- inner_join(combined_x, cmb, by = c("AssociateID", "SortableDate", "SiteNumber", "TotalShiftsWorked"))
combined_x<- combined_x[order(combined_x$AssociateID, combined_x$SortableDate), ]

for(p in 1:nrow(combined_x)){
  if(is.na(combined_x$HrsWorked[p])){
    combined_x$HrsWorked[p] <- 0
    combined_x$TotalClockins[p] <- 0
  }else{
    next
  }
}

combined_x$Date <- NA
combined_x$Date <- paste( (as.integer(substr(combined_x$SortableDate, 1, 4))) , (as.integer(substr(combined_x$SortableDate, 5, 6))) , (as.integer(substr(combined_x$SortableDate, 7, 8))), sep = "/")
combined_x$Date <- as.Date(combined_x$Date)

combined_x$PercentageShiftCovered <- combined_x$HrsCovered/combined_x$HrsScheduled
combined_x$PercentageWorkedToScheduledHrs <- combined_x$HrsWorked/combined_x$HrsScheduled

#Create Indicator Variables!

#ASSUMPTIONS
#allow for 5 mins late, leaving 5 mins early
#allow for 15 mins break every 4 hrs -- aka 3.75 mins of break per hour

combined_x$Tolerance <- ((combined_x$HrsScheduled*60) - (10 + (combined_x$HrsScheduled*3.75))) / (combined_x$HrsScheduled*60)

combined_x$Cov_Indicator <- 0
combined_x$NOT_Cov_Indicator <- 1
combined_x$Hrs_Indicator <- 0
combined_x$NOT_Hrs_Indicator <- 1

for(d in 1:nrow(combined_x)){
  if(is.na(combined_x$PercentageShiftCovered[d]) == TRUE | is.na(combined_x$PercentageWorkedToScheduledHrs[d]) == TRUE){
    next
  }
  if(combined_x$PercentageShiftCovered[d] >= combined_x$Tolerance[d]){
      combined_x$Cov_Indicator[d] <- 1
      combined_x$NOT_Cov_Indicator[d] <- 0
  }
  
  if(combined_x$PercentageWorkedToScheduledHrs[d] >= combined_x$Tolerance[d]){
    combined_x$Hrs_Indicator[d] <- 1
    combined_x$NOT_Hrs_Indicator[d] <- 0
  }
}

# add store location

store_loc <- read.csv("store_location.csv", stringsAsFactors = FALSE)
names(store_loc)[1] <- "SiteNumber"
names(store_loc)[2] <- "Address"
names(store_loc)[5] <- "State"
store_loc$Additional <- NULL

combined_x <- merge(combined_x, store_loc, all.x = TRUE, by = "SiteNumber")

#Data integrity issue (lose one row, two columns related to break times, until issue is fixed)

combined_x$AvgMinsBetweenClockins <- NULL
combined_x$BreaksLongerThan15min <- NULL

#Final two tables below  

combined_x <- combined_x[order(combined_x$AssociateID, combined_x$SortableDate), ]

combined <- merge(combined, store_loc, all.x = TRUE, by = "SiteNumber")
combined <- combined[order(combined$AssociateID, combined$SortableDate), ]

# write.csv(combined_x, "worked.csv")
# write.csv(combined, "worked_expanded.csv")
